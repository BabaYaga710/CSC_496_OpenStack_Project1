#!/bin/sh

##
## Initialize some basic x86_64 stuff.
##

exit 0
