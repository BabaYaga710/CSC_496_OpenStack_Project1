#!/bin/sh

##
## Initialize some basic aarch64 stuff.
##

exit 0
